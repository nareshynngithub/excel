﻿using System;
using System.Linq;
using System.Threading;

namespace ExcelUtilityReadingBlob
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Starting conversion process...");
            ExcelConversionUtility.ExcelConversionUtility excelConversionUtility = new ExcelConversionUtility.ExcelConversionUtility();
			excelConversionUtility.Process().GetAwaiter().GetResult();
			Console.WriteLine("Conversion process completed.");
		}     

    }
}
