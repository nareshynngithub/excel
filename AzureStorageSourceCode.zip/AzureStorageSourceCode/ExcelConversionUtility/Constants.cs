﻿using System;

namespace ExcelConversionUtility
{
	public static class Constants
	{
		public static string ConnectionString = Environment.GetEnvironmentVariable("AZURE_STORAGE_CONNECTION_STRING");
		public static string CSVContainerName = "csvcontainer";
		public static string ExcelContainerName = "excelcontainer";
	}
}
